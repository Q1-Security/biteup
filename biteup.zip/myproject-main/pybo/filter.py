def format_datetime(value, fmt='%Y-%m-%d %H:%M'):
    return value.strftime(fmt)